# AppMaze

**Don't block the distraction. Break the habit.**

A native Android launcher that detects distracting apps by real screen-time
usage (`UsageStatsManager`) and scrambles their grid position, adding a few
seconds of friction between impulse and habitual tap — without ever blocking
access.

## ⚠️ Why you didn't get a `.apk` file directly

Compiling this into an installable APK requires the Android SDK, build-tools,
and Google's Maven repository (for AndroidX/Compose/Room dependencies) — none
of which are available in the sandbox that generated this project. What's
included here is the **complete, real source code** for the app described in
the spec — not a mockup. You build the actual APK on your own machine, where
Android Studio already has the SDK.

## Build it yourself (takes 2–5 minutes)

1. Install **Android Studio** (Koala or newer) if you don't have it.
2. Open this folder (`AppMaze/`) in Android Studio: **File → Open**.
3. Let Gradle sync (first sync downloads dependencies — needs internet).
4. Plug in an Android phone (Developer Options + USB debugging on) or start
   an emulator (API 26+).
5. Click **Run ▶** to install a debug build, or
   **Build → Generate Signed App Bundle / APK** for a release
   `app-release.apk`.
6. On the phone: press **Home**, pick **AppMaze**, and set it as default.
7. Go through onboarding, pick a few distracting apps, and use your phone
   normally — AppMaze starts scrambling their position once they cross your
   configured screen-time threshold.

If you don't have Android Studio installed, `sdkmanager` + `gradlew
assembleDebug` from the command line also works once the SDK is installed.

## What's implemented

- **Custom launcher** (`MainActivity` registered for `HOME`/`DEFAULT`) that
  dynamically enumerates installed launchable apps via `PackageManager` —
  nothing hardcoded.
- **Real screen-time tracking** via `UsageStatsManager` (`usage/UsageStatsHelper.kt`),
  100% on-device, no network calls, no backend.
- **Distraction scoring** with user-editable thresholds
  (`data/SettingsRepository.kt`, `scrambling/ScramblingEngine.kt`).
- **Scrambling engine** with Gentle / Moderate / Strong / Custom intensity,
  cooldowns, and essential-app protection (`scrambling/ScramblingEngine.kt`).
- **Choose Your Distractions** screen with manual toggles + auto-detect.
- **Optional "Open Anyway / Take a Break" intervention** before launching a
  highly distracting app.
- **Dashboard** with today's screen time, top apps, distraction list, and
  scramble/interruption activity counters.
- **Full Settings** (scrambling, thresholds, appearance, launcher, privacy,
  developer/demo mode).
- **6-screen onboarding** matching the spec exactly.
- **Demo mode** to simulate usage and trigger scrambles instantly for demos.
- **Room** for persistent app positions/state, **DataStore** for preferences.
- Material 3, light/dark/system theme, calm non-alarming visual language.

## Project layout

```
app/src/main/java/com/appmaze/app/
├── apps/          installed-app discovery + launch
├── data/          Room entities/DAO/DB, DataStore settings
├── launcher/       LauncherViewModel — the app's brain
├── navigation/     Compose NavHost wiring all screens
├── scrambling/     ScramblingEngine — the core algorithm
├── ui/screens/     Home, Onboarding, Dashboard, Settings, Demo, etc.
├── ui/theme/       Material 3 theme
├── usage/          UsageStatsManager wrapper
└── MainActivity.kt
```

## Known follow-ups before a store release

- App icons are simple placeholder vectors — swap in real branded assets.
- No drag-and-drop manual repositioning yet (positions currently only change
  via the scrambling engine or "Reset positions").
- App categories are stored but there's no dedicated category-editing UI yet.
- No automated tests included — add unit tests for `ScramblingEngine`
  (it's pure logic over the DAO, easy to test with an in-memory Room DB).
