package com.appmaze.app.launcher

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.appmaze.app.AppMazeApplication

class LauncherViewModelFactory(private val app: AppMazeApplication) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(LauncherViewModel::class.java)) {
            return LauncherViewModel(app) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
