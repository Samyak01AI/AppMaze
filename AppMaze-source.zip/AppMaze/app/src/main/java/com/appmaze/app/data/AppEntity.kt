package com.appmaze.app.data

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Persistent record for every launchable app AppMaze knows about.
 * This is the single source of truth for grid position, distraction
 * status, and usage snapshot — matches the model described in the spec
 * (Section 18: APP POSITION STORAGE).
 */
@Entity(tableName = "apps")
data class AppEntity(
    @PrimaryKey val packageName: String,
    val appName: String,
    val position: Int,
    val category: String = "Uncategorized",
    val isDistracting: Boolean = false,
    val isEssential: Boolean = false,       // Phone, Settings, SOS, system apps
    val distractionScore: Int = 0,          // 0-100
    val lastScrambledAt: Long = 0L,
    val dailyUsageMillis: Long = 0L,
    val launchCount: Int = 0,
    val manuallyMarked: Boolean = false      // user explicitly toggled distracting ON/OFF
)
