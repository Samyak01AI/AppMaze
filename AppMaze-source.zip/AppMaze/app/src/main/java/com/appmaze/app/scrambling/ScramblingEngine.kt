package com.appmaze.app.scrambling

import com.appmaze.app.data.*
import kotlin.random.Random

/**
 * Determines WHEN and WHERE a distracting app should move.
 *
 * Design goals (Sections 7-9, 19):
 *  - Never touch essential apps unless the user explicitly opted them in.
 *  - Never move an app more often than the configured cooldown allows.
 *  - Keep the rest of the grid stable — only distracting apps get moved.
 *  - Avoid ping-ponging an app between the same two slots.
 *  - Scale "how far" and "how often" by intensity, not raw randomness.
 */
class ScramblingEngine(
    private val appDao: AppDao,
    private val scrambleDao: ScrambleDao
) {

    private data class IntensityProfile(
        val cooldownMinutes: Int,   // minimum time between scrambles for the same app
        val minShift: Int,          // minimum positions moved
        val maxShift: Int           // maximum positions moved
    )

    private fun profileFor(settings: AppMazeSettings): IntensityProfile = when (settings.intensity) {
        ScrambleIntensity.GENTLE -> IntensityProfile(cooldownMinutes = 45, minShift = 1, maxShift = 3)
        ScrambleIntensity.MODERATE -> IntensityProfile(cooldownMinutes = 20, minShift = 3, maxShift = 6)
        ScrambleIntensity.STRONG -> IntensityProfile(cooldownMinutes = 8, minShift = 5, maxShift = 12)
        ScrambleIntensity.CUSTOM -> IntensityProfile(
            cooldownMinutes = settings.customFrequencyMinutes,
            minShift = settings.customMinShift,
            maxShift = settings.customMaxShift
        )
    }

    /** 0-15 normal, 15-30 low, 30-60 moderate, 60+ high (Section 5), thresholds are user-configurable. */
    fun computeDistractionScore(usageMillis: Long, settings: AppMazeSettings): Int {
        val minutes = usageMillis / 60000
        return when {
            minutes < settings.thresholdLowMinutes -> 0
            minutes < settings.thresholdModerateMinutes -> 25
            minutes < settings.thresholdHighMinutes -> 60
            else -> 100
        }
    }

    /**
     * Re-evaluates every distracting, non-essential app and scrambles the ones
     * that have crossed their threshold and are out of cooldown.
     * Returns the list of packages that were actually moved (for UI feedback / dashboard).
     */
    suspend fun evaluateAndScramble(settings: AppMazeSettings): List<String> {
        if (!settings.scramblingEnabled) return emptyList()

        val profile = profileFor(settings)
        val all = appDao.getAllOnce()
        val maxPosition = all.maxOfOrNull { it.position } ?: 0
        val now = System.currentTimeMillis()
        val cooldownMillis = profile.cooldownMinutes * 60_000L

        val moved = mutableListOf<String>()

        for (app in all) {
            if (app.isEssential) continue
            if (!app.isDistracting) continue
            if (app.distractionScore < 25) continue // below "low distraction" — leave it alone
            if (now - app.lastScrambledAt < cooldownMillis) continue

            val shiftAmount = Random.nextInt(profile.minShift, profile.maxShift + 1)
            val direction = if (Random.nextBoolean()) 1 else -1
            var newPosition = app.position + (shiftAmount * direction)
            newPosition = newPosition.coerceIn(0, maxOf(maxPosition, 1))

            // Avoid landing back on (or very near) the same slot.
            if (kotlin.math.abs(newPosition - app.position) < profile.minShift) {
                newPosition = (app.position + profile.minShift).coerceAtMost(maxPosition)
            }

            val occupant = all.firstOrNull { it.position == newPosition && it.packageName != app.packageName }
            if (occupant != null) {
                // Swap so no two apps ever share a slot.
                appDao.updatePosition(occupant.packageName, app.position, now)
            }
            appDao.updatePosition(app.packageName, newPosition, now)
            scrambleDao.insertScramble(
                ScrambleEvent(
                    packageName = app.packageName,
                    fromPosition = app.position,
                    toPosition = newPosition,
                    timestamp = now,
                    reasonThresholdMinutes = settings.thresholdModerateMinutes
                )
            )
            moved += app.packageName
        }
        return moved
    }

    /** Call when the user reopens an app that was scrambled recently — powers "habitual taps interrupted". */
    suspend fun recordPossibleInterruption(packageName: String) {
        val app = appDao.getByPackage(packageName) ?: return
        val recentlyScrambled = System.currentTimeMillis() - app.lastScrambledAt < 10 * 60_000L
        if (recentlyScrambled) {
            scrambleDao.insertInterruption(InterruptionEvent(packageName = packageName, timestamp = System.currentTimeMillis()))
        }
    }

    /** Section 14 settings: "Reset app positions" — restores alphabetical-by-insertion order. */
    suspend fun resetPositions() {
        val all = appDao.getAllOnce().sortedBy { it.appName.lowercase() }
        val updated = all.mapIndexed { index, app -> app.copy(position = index, lastScrambledAt = 0L) }
        appDao.updateAll(updated)
    }

    /** Manual "Scramble Now" for demo mode (Section 20) / a single app. */
    suspend fun forceScramble(packageName: String, settings: AppMazeSettings) {
        val app = appDao.getByPackage(packageName) ?: return
        if (app.isEssential) return
        val profile = profileFor(settings)
        val maxPosition = appDao.getMaxPosition() ?: 0
        val shift = Random.nextInt(profile.minShift, profile.maxShift + 1)
        val newPosition = (app.position + shift).coerceIn(0, maxOf(maxPosition, 1))
        appDao.updatePosition(app.packageName, newPosition, System.currentTimeMillis())
        scrambleDao.insertScramble(
            ScrambleEvent(app.packageName, app.position, newPosition, System.currentTimeMillis(), 0)
        )
    }
}
