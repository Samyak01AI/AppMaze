package com.appmaze.app

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.viewmodel.compose.viewModel
import com.appmaze.app.launcher.LauncherViewModel
import com.appmaze.app.launcher.LauncherViewModelFactory
import com.appmaze.app.navigation.AppMazeNavHost
import com.appmaze.app.ui.theme.AppMazeTheme

/**
 * Single-activity host. Because this Activity is registered with both
 * the LAUNCHER and HOME/DEFAULT intent categories (see AndroidManifest),
 * Android offers it as a selectable Home Screen app — this is what makes
 * AppMaze a real, installable launcher (Section 3).
 */
class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val application = application as AppMazeApplication

        setContent {
            val viewModel: LauncherViewModel = viewModel(factory = LauncherViewModelFactory(application))
            val settings by viewModel.settings.collectAsState()

            val lifecycleOwner = LocalLifecycleOwner.current
            DisposableEffect(lifecycleOwner) {
                val observer = LifecycleEventObserver { _, event ->
                    if (event == Lifecycle.Event.ON_RESUME) viewModel.refreshAppsAndUsage()
                }
                lifecycleOwner.lifecycle.addObserver(observer)
                onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
            }

            AppMazeTheme(theme = settings.theme) {
                AppMazeNavHost(
                    viewModel = viewModel,
                    onRequestUsageAccess = {
                        startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
                    },
                    onRequestDefaultLauncher = { requestDefaultLauncher() }
                )
            }
        }
    }

    /** Opens the system's "Home app" picker so the user can select AppMaze as default launcher. */
    private fun requestDefaultLauncher() {
        val intent = Intent(Settings.ACTION_HOME_SETTINGS)
        startActivity(intent)
    }
}
