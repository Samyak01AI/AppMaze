package com.appmaze.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.appmaze.app.data.AppMazeSettings
import com.appmaze.app.data.AppTheme
import com.appmaze.app.data.ScrambleIntensity

@Composable
fun SettingsScreen(
    settings: AppMazeSettings,
    hasUsageAccess: Boolean,
    onBack: () -> Unit,
    onScramblingEnabledChange: (Boolean) -> Unit,
    onIntensityChange: (ScrambleIntensity) -> Unit,
    onAutoDetectChange: (Boolean) -> Unit,
    onInterventionChange: (Boolean) -> Unit,
    onThemeChange: (AppTheme) -> Unit,
    onDemoModeChange: (Boolean) -> Unit,
    onRequestUsageAccess: () -> Unit,
    onResetLayout: () -> Unit,
    onSetAsDefaultLauncher: () -> Unit,
    onOpenChooseDistractions: () -> Unit
) {
    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(20.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) {
                Icon(androidx.compose.material.icons.Icons.Filled.ArrowBack, contentDescription = "Back")
            }
            Text("Settings", style = MaterialTheme.typography.headlineMedium)
        }

        SectionHeader("Scrambling")
        SettingsSwitchRow("Enable scrambling", settings.scramblingEnabled, onScramblingEnabledChange)
        IntensitySelector(settings.intensity, onIntensityChange)
        TextButton(onClick = onOpenChooseDistractions) { Text("Choose your distractions") }

        SectionHeader("Screen Time")
        SettingsSwitchRow("Automatically detect distracting apps", settings.autoDetectDistracting, onAutoDetectChange)
        SettingsSwitchRow("Show open-app intervention", settings.interventionEnabled, onInterventionChange)
        if (!hasUsageAccess) {
            Button(onClick = onRequestUsageAccess) { Text("Enable Usage Access") }
        } else {
            Text("Usage Access: granted", style = MaterialTheme.typography.bodyMedium)
        }

        SectionHeader("Appearance")
        ThemeSelector(settings.theme, onThemeChange)

        SectionHeader("Launcher")
        TextButton(onClick = onResetLayout) { Text("Reset app positions") }
        TextButton(onClick = onSetAsDefaultLauncher) { Text("Set as default launcher") }

        SectionHeader("Privacy")
        Text(
            "Your screen-time data stays on your device. AppMaze does not upload usage history, " +
                "installed app lists, or personal data to any server.",
            style = MaterialTheme.typography.bodyMedium
        )

        SectionHeader("Developer")
        SettingsSwitchRow("Demo mode", settings.demoModeEnabled, onDemoModeChange)

        Spacer(Modifier.height(24.dp))
    }
}

@Composable
private fun SectionHeader(title: String) {
    Spacer(Modifier.height(18.dp))
    Text(title, style = MaterialTheme.typography.titleMedium)
    Spacer(Modifier.height(6.dp))
}

@Composable
private fun SettingsSwitchRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, style = MaterialTheme.typography.bodyLarge, modifier = Modifier.weight(1f))
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
private fun IntensitySelector(current: ScrambleIntensity, onChange: (ScrambleIntensity) -> Unit) {
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        ScrambleIntensity.values().forEach { intensity ->
            FilterChip(
                selected = current == intensity,
                onClick = { onChange(intensity) },
                label = { Text(intensity.name.lowercase().replaceFirstChar { it.uppercase() }) }
            )
        }
    }
}

@Composable
private fun ThemeSelector(current: AppTheme, onChange: (AppTheme) -> Unit) {
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        AppTheme.values().forEach { theme ->
            FilterChip(
                selected = current == theme,
                onClick = { onChange(theme) },
                label = { Text(theme.name.lowercase().replaceFirstChar { it.uppercase() }) }
            )
        }
    }
}
