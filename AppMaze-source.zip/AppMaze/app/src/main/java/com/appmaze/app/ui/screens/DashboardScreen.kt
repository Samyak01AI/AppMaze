package com.appmaze.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.appmaze.app.launcher.GridApp

data class DashboardStats(
    val todayTotalMillis: Long,
    val topApps: List<GridApp>,
    val distractingApps: List<GridApp>,
    val scramblesToday: Int,
    val interruptionsToday: Int
)

@Composable
fun DashboardScreen(stats: DashboardStats, onBack: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(20.dp)) {
        Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
            IconButton(onClick = onBack) {
                Icon(androidx.compose.material.icons.Icons.Filled.ArrowBack, contentDescription = "Back")
            }
            Text("Dashboard", style = MaterialTheme.typography.headlineMedium)
        }
        Spacer(Modifier.height(16.dp))

        StatCard(title = "Today's Screen Time", value = formatDuration(stats.todayTotalMillis))

        Spacer(Modifier.height(16.dp))
        Text("Top Apps", style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(8.dp))
        LazyColumn {
            items(stats.topApps.take(5)) { app ->
                Row(
                    Modifier.fillMaxWidth().padding(vertical = 6.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(app.appName)
                    Text(formatDuration(app.dailyUsageMillis))
                }
            }
        }

        Spacer(Modifier.height(16.dp))
        Text("Distraction Apps", style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(8.dp))
        Text(
            stats.distractingApps.joinToString(", ") { it.appName }.ifBlank { "None selected yet" },
            style = MaterialTheme.typography.bodyMedium
        )

        Spacer(Modifier.height(16.dp))
        Text("AppMaze Activity", style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            StatCard(title = "Apps scrambled today", value = "${stats.scramblesToday}", modifier = Modifier.weight(1f))
            StatCard(title = "Habitual taps interrupted", value = "${stats.interruptionsToday}", modifier = Modifier.weight(1f))
        }
    }
}

@Composable
private fun StatCard(title: String, value: String, modifier: Modifier = Modifier) {
    Surface(shape = RoundedCornerShape(16.dp), color = MaterialTheme.colorScheme.surfaceVariant, modifier = modifier) {
        Column(Modifier.padding(16.dp)) {
            Text(title, style = MaterialTheme.typography.bodyMedium)
            Text(value, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
        }
    }
}
