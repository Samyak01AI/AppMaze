package com.appmaze.app.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface AppDao {

    @Query("SELECT * FROM apps ORDER BY position ASC")
    fun observeAll(): Flow<List<AppEntity>>

    @Query("SELECT * FROM apps ORDER BY position ASC")
    suspend fun getAllOnce(): List<AppEntity>

    @Query("SELECT * FROM apps WHERE packageName = :pkg LIMIT 1")
    suspend fun getByPackage(pkg: String): AppEntity?

    @Query("SELECT * FROM apps WHERE isDistracting = 1")
    suspend fun getDistractingApps(): List<AppEntity>

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertAll(apps: List<AppEntity>)

    @Update
    suspend fun update(app: AppEntity)

    @Update
    suspend fun updateAll(apps: List<AppEntity>)

    @Query("DELETE FROM apps WHERE packageName = :pkg")
    suspend fun deleteByPackage(pkg: String)

    @Query("UPDATE apps SET position = :position, lastScrambledAt = :timestamp WHERE packageName = :pkg")
    suspend fun updatePosition(pkg: String, position: Int, timestamp: Long)

    @Query("UPDATE apps SET dailyUsageMillis = :usage, distractionScore = :score WHERE packageName = :pkg")
    suspend fun updateUsage(pkg: String, usage: Long, score: Int)

    @Query("UPDATE apps SET isDistracting = :distracting, manuallyMarked = 1 WHERE packageName = :pkg")
    suspend fun setDistracting(pkg: String, distracting: Boolean)

    @Query("UPDATE apps SET dailyUsageMillis = 0")
    suspend fun resetDailyUsage()

    @Query("SELECT MAX(position) FROM apps")
    suspend fun getMaxPosition(): Int?
}
