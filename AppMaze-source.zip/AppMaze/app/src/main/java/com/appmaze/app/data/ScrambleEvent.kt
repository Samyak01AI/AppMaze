package com.appmaze.app.data

import androidx.room.Entity
import androidx.room.PrimaryKey
import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

/** One row per scramble action — powers the "AppMaze Activity" dashboard section. */
@Entity(tableName = "scramble_events")
data class ScrambleEvent(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val packageName: String,
    val fromPosition: Int,
    val toPosition: Int,
    val timestamp: Long,
    val reasonThresholdMinutes: Int
)

/** One row per time the user re-opened an app that had just been scrambled — "habitual taps interrupted". */
@Entity(tableName = "interruption_events")
data class InterruptionEvent(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val packageName: String,
    val timestamp: Long
)

@Dao
interface ScrambleDao {
    @Insert
    suspend fun insertScramble(event: ScrambleEvent)

    @Insert
    suspend fun insertInterruption(event: InterruptionEvent)

    @Query("SELECT COUNT(*) FROM scramble_events WHERE timestamp >= :sinceMidnight")
    fun observeTodayScrambleCount(sinceMidnight: Long): Flow<Int>

    @Query("SELECT COUNT(*) FROM interruption_events WHERE timestamp >= :sinceMidnight")
    fun observeTodayInterruptionCount(sinceMidnight: Long): Flow<Int>

    @Query("SELECT * FROM scramble_events ORDER BY timestamp DESC LIMIT 200")
    fun observeRecentScrambles(): Flow<List<ScrambleEvent>>
}
