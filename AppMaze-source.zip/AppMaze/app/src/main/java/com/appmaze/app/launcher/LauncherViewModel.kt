package com.appmaze.app.launcher

import android.graphics.drawable.Drawable
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.appmaze.app.AppMazeApplication
import com.appmaze.app.apps.InstalledAppsRepository
import com.appmaze.app.data.*
import com.appmaze.app.scrambling.ScramblingEngine
import com.appmaze.app.usage.UsageStatsHelper
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

data class GridApp(
    val packageName: String,
    val appName: String,
    val position: Int,
    val icon: Drawable?,
    val isDistracting: Boolean,
    val isEssential: Boolean,
    val distractionScore: Int,
    val dailyUsageMillis: Long
)

data class HomeUiState(
    val apps: List<GridApp> = emptyList(),
    val searchQuery: String = "",
    val todayTotalUsageMillis: Long = 0L,
    val hasUsageAccess: Boolean = false,
    val pendingIntervention: GridApp? = null
)

class LauncherViewModel(private val app: AppMazeApplication) : ViewModel() {

    private val appDao = app.database.appDao()
    private val scrambleDao = app.database.scrambleDao()
    private val installedRepo: InstalledAppsRepository = app.installedAppsRepository
    private val usageHelper: UsageStatsHelper = app.usageStatsHelper
    private val scrambler: ScramblingEngine = app.scramblingEngine
    private val settingsRepo = app.settingsRepository

    private val _searchQuery = MutableStateFlow("")
    private val _pendingIntervention = MutableStateFlow<GridApp?>(null)

    val settings: StateFlow<AppMazeSettings> = settingsRepo.settingsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), AppMazeSettings())

    val uiState: StateFlow<HomeUiState> = combine(
        appDao.observeAll(),
        _searchQuery,
        _pendingIntervention
    ) { entities, query, intervention ->
        val iconMap = installedRepo.queryLaunchableApps().associateBy { it.packageName }
        val gridApps = entities
            .filter { query.isBlank() || it.appName.contains(query, ignoreCase = true) }
            .sortedBy { it.position }
            .map { e ->
                GridApp(
                    packageName = e.packageName,
                    appName = e.appName,
                    position = e.position,
                    icon = iconMap[e.packageName]?.icon,
                    isDistracting = e.isDistracting,
                    isEssential = e.isEssential,
                    distractionScore = e.distractionScore,
                    dailyUsageMillis = e.dailyUsageMillis
                )
            }
        HomeUiState(
            apps = gridApps,
            searchQuery = query,
            todayTotalUsageMillis = entities.sumOf { it.dailyUsageMillis },
            hasUsageAccess = usageHelper.hasUsageAccessPermission(),
            pendingIntervention = intervention
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), HomeUiState())

    init {
        refreshAppsAndUsage()
    }

    fun refreshAppsAndUsage() {
        viewModelScope.launch {
            installedRepo.syncInstalledAppsToDb()
            syncUsageStats()
            scrambler.evaluateAndScramble(settings.value)
        }
    }

    private suspend fun syncUsageStats() {
        if (!usageHelper.hasUsageAccessPermission()) return
        val usage = usageHelper.getTodayUsagePerApp()
        val current = appDao.getAllOnce()
        for (entity in current) {
            val ms = usage[entity.packageName] ?: 0L
            val score = scrambler.computeDistractionScore(ms, settings.value)
            appDao.updateUsage(entity.packageName, ms, score)
            // Auto-detect: if enabled and score is high, and user hasn't manually overridden, mark distracting.
            if (settings.value.autoDetectDistracting && !entity.manuallyMarked && score >= 60 && !entity.isDistracting) {
                appDao.setDistracting(entity.packageName, true)
            }
        }
    }

    fun onSearchQueryChange(query: String) { _searchQuery.value = query }

    /**
     * Called when the user taps an app icon. Handles the optional
     * intervention screen (Section 10) before actually launching.
     */
    fun onAppTapped(app: GridApp, skipIntervention: Boolean = false) {
        viewModelScope.launch {
            scrambler.recordPossibleInterruption(app.packageName)
            val shouldIntervene = settings.value.interventionEnabled &&
                app.isDistracting && app.distractionScore >= 60 && !skipIntervention
            if (shouldIntervene) {
                _pendingIntervention.value = app
            } else {
                installedRepo.launchApp(app.packageName)
            }
        }
    }

    fun confirmOpenAnyway() {
        val app = _pendingIntervention.value ?: return
        _pendingIntervention.value = null
        installedRepo.launchApp(app.packageName)
    }

    fun dismissIntervention() { _pendingIntervention.value = null }

    fun toggleDistracting(packageName: String, distracting: Boolean) {
        viewModelScope.launch { appDao.setDistracting(packageName, distracting) }
    }

    fun resetLayout() {
        viewModelScope.launch { scrambler.resetPositions() }
    }

    // --- Demo / Test mode (Section 20) ---------------------------------

    fun simulateUsage(packageName: String, addMinutes: Int) {
        viewModelScope.launch {
            val entity = appDao.getByPackage(packageName) ?: return@launch
            val newUsage = entity.dailyUsageMillis + addMinutes * 60_000L
            val score = scrambler.computeDistractionScore(newUsage, settings.value)
            appDao.updateUsage(packageName, newUsage, score)
            scrambler.evaluateAndScramble(settings.value)
        }
    }

    fun scrambleNow(packageName: String) {
        viewModelScope.launch { scrambler.forceScramble(packageName, settings.value) }
    }

    // --- Settings passthroughs ------------------------------------------

    fun setScramblingEnabled(enabled: Boolean) = viewModelScope.launch { settingsRepo.setScramblingEnabled(enabled) }
    fun setIntensity(intensity: ScrambleIntensity) = viewModelScope.launch { settingsRepo.setIntensity(intensity) }
    fun setAutoDetect(enabled: Boolean) = viewModelScope.launch { settingsRepo.setAutoDetect(enabled) }
    fun setIntervention(enabled: Boolean) = viewModelScope.launch { settingsRepo.setIntervention(enabled) }
    fun setTheme(theme: AppTheme) = viewModelScope.launch { settingsRepo.setTheme(theme) }
    fun setDemoMode(enabled: Boolean) = viewModelScope.launch { settingsRepo.setDemoMode(enabled) }
    fun setOnboardingComplete(done: Boolean) = viewModelScope.launch { settingsRepo.setOnboardingComplete(done) }
}
