package com.appmaze.app.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import com.appmaze.app.data.AppTheme

private val DarkColors = darkColorScheme(
    primary = MazeIndigoLight,
    secondary = MazeAmber,
    tertiary = MazeSage,
    background = DarkBackground,
    surface = DarkSurface
)

private val LightColors = lightColorScheme(
    primary = MazeIndigo,
    secondary = MazeAmber,
    tertiary = MazeSage,
    background = LightBackground,
    surface = LightSurface
)

@Composable
fun AppMazeTheme(theme: AppTheme = AppTheme.SYSTEM, content: @Composable () -> Unit) {
    val useDark = when (theme) {
        AppTheme.LIGHT -> false
        AppTheme.DARK -> true
        AppTheme.SYSTEM -> isSystemInDarkTheme()
    }
    MaterialTheme(
        colorScheme = if (useDark) DarkColors else LightColors,
        typography = AppMazeTypography,
        content = content
    )
}
