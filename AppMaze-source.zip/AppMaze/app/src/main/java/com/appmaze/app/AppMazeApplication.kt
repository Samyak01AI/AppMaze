package com.appmaze.app

import android.app.Application
import com.appmaze.app.apps.InstalledAppsRepository
import com.appmaze.app.data.AppMazeDatabase
import com.appmaze.app.data.SettingsRepository
import com.appmaze.app.scrambling.ScramblingEngine
import com.appmaze.app.usage.UsageStatsHelper

class AppMazeApplication : Application() {

    val database by lazy { AppMazeDatabase.getInstance(this) }
    val settingsRepository by lazy { SettingsRepository(this) }
    val usageStatsHelper by lazy { UsageStatsHelper(this) }
    val installedAppsRepository by lazy { InstalledAppsRepository(this, database.appDao()) }
    val scramblingEngine by lazy { ScramblingEngine(database.appDao(), database.scrambleDao()) }
}
