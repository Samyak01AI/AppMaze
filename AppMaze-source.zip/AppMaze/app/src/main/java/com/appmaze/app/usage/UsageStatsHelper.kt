package com.appmaze.app.usage

import android.app.AppOpsManager
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.os.Process
import android.provider.Settings
import java.util.Calendar

/**
 * Wraps Android's UsageStatsManager (Section 4: SCREEN-TIME TRACKING).
 * All numbers returned here are computed on-device and never leave it.
 */
class UsageStatsHelper(private val context: Context) {

    /** True if the user has granted "Usage Access" (PACKAGE_USAGE_STATS) via system Settings. */
    fun hasUsageAccessPermission(): Boolean {
        val appOps = context.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        val mode = appOps.unsafeCheckOpNoThrow(
            AppOpsManager.OPSTR_GET_USAGE_STATS,
            Process.myUid(),
            context.packageName
        )
        return mode == AppOpsManager.MODE_ALLOWED
    }

    /** Deep-links the user straight to the system screen where Usage Access is granted. */
    fun requestUsageAccessIntent(): Intent =
        Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)

    private fun startOfTodayMillis(): Long {
        val cal = Calendar.getInstance()
        cal.set(Calendar.HOUR_OF_DAY, 0)
        cal.set(Calendar.MINUTE, 0)
        cal.set(Calendar.SECOND, 0)
        cal.set(Calendar.MILLISECOND, 0)
        return cal.timeInMillis
    }

    /** Returns package -> foreground milliseconds used today. */
    fun getTodayUsagePerApp(): Map<String, Long> =
        getUsagePerApp(startOfTodayMillis(), System.currentTimeMillis())

    /** Returns package -> foreground milliseconds used in the trailing 7 days. */
    fun getWeeklyUsagePerApp(): Map<String, Long> {
        val end = System.currentTimeMillis()
        val start = end - 7L * 24 * 60 * 60 * 1000
        return getUsagePerApp(start, end)
    }

    private fun getUsagePerApp(start: Long, end: Long): Map<String, Long> {
        if (!hasUsageAccessPermission()) return emptyMap()
        val usm = context.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val stats = usm.queryUsageStats(UsageStatsManager.INTERVAL_DAILY, start, end)
        return stats
            .filter { it.totalTimeInForeground > 0 }
            .groupBy { it.packageName }
            .mapValues { (_, list) -> list.sumOf { it.totalTimeInForeground } }
    }

    /**
     * Approximate launch counts per app today, derived from ACTIVITY_RESUMED events.
     * (UsageStatsManager has no direct "launch count" field, so we count resume events.)
     */
    fun getTodayLaunchCounts(): Map<String, Int> {
        if (!hasUsageAccessPermission()) return emptyMap()
        val usm = context.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val start = startOfTodayMillis()
        val end = System.currentTimeMillis()
        val events = usm.queryEvents(start, end)
        val counts = mutableMapOf<String, Int>()
        val event = UsageEvents.Event()
        while (events.hasNextEvent()) {
            events.getNextEvent(event)
            if (event.eventType == UsageEvents.Event.ACTIVITY_RESUMED) {
                counts[event.packageName] = (counts[event.packageName] ?: 0) + 1
            }
        }
        return counts
    }
}
