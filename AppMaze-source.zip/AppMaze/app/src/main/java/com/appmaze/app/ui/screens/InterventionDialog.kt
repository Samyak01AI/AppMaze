package com.appmaze.app.ui.screens

import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import com.appmaze.app.launcher.GridApp

@Composable
fun InterventionDialog(
    app: GridApp,
    onOpenAnyway: () -> Unit,
    onTakeBreak: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onTakeBreak,
        title = { Text(app.appName) },
        text = { Text("You've spent ${formatDuration(app.dailyUsageMillis)} here today. Do you still want to open it?") },
        confirmButton = { TextButton(onClick = onOpenAnyway) { Text("Open Anyway") } },
        dismissButton = { TextButton(onClick = onTakeBreak) { Text("Take a Break") } }
    )
}
