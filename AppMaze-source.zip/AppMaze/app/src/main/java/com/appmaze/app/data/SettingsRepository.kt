package com.appmaze.app.data

import android.content.Context
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

val Context.dataStore by preferencesDataStore(name = "appmaze_settings")

enum class ScrambleIntensity { GENTLE, MODERATE, STRONG, CUSTOM }
enum class AppTheme { LIGHT, DARK, SYSTEM }

data class AppMazeSettings(
    val onboardingComplete: Boolean = false,
    val scramblingEnabled: Boolean = true,
    val intensity: ScrambleIntensity = ScrambleIntensity.GENTLE,
    val thresholdLowMinutes: Int = 15,
    val thresholdModerateMinutes: Int = 30,
    val thresholdHighMinutes: Int = 60,
    val autoDetectDistracting: Boolean = true,
    val interventionEnabled: Boolean = true,
    val theme: AppTheme = AppTheme.SYSTEM,
    val gridColumns: Int = 4,
    val showLabels: Boolean = true,
    val demoModeEnabled: Boolean = false,
    // custom-mode-only knobs
    val customFrequencyMinutes: Int = 20,
    val customMinShift: Int = 2,
    val customMaxShift: Int = 8
)

class SettingsRepository(private val context: Context) {

    private object Keys {
        val ONBOARDING = booleanPreferencesKey("onboarding_complete")
        val SCRAMBLING_ENABLED = booleanPreferencesKey("scrambling_enabled")
        val INTENSITY = stringPreferencesKey("intensity")
        val THRESH_LOW = intPreferencesKey("thresh_low")
        val THRESH_MOD = intPreferencesKey("thresh_mod")
        val THRESH_HIGH = intPreferencesKey("thresh_high")
        val AUTO_DETECT = booleanPreferencesKey("auto_detect")
        val INTERVENTION = booleanPreferencesKey("intervention_enabled")
        val THEME = stringPreferencesKey("theme")
        val GRID_COLS = intPreferencesKey("grid_columns")
        val SHOW_LABELS = booleanPreferencesKey("show_labels")
        val DEMO_MODE = booleanPreferencesKey("demo_mode")
        val CUSTOM_FREQ = intPreferencesKey("custom_freq")
        val CUSTOM_MIN_SHIFT = intPreferencesKey("custom_min_shift")
        val CUSTOM_MAX_SHIFT = intPreferencesKey("custom_max_shift")
    }

    val settingsFlow: Flow<AppMazeSettings> = context.dataStore.data.map { p ->
        AppMazeSettings(
            onboardingComplete = p[Keys.ONBOARDING] ?: false,
            scramblingEnabled = p[Keys.SCRAMBLING_ENABLED] ?: true,
            intensity = runCatching { ScrambleIntensity.valueOf(p[Keys.INTENSITY] ?: "GENTLE") }
                .getOrDefault(ScrambleIntensity.GENTLE),
            thresholdLowMinutes = p[Keys.THRESH_LOW] ?: 15,
            thresholdModerateMinutes = p[Keys.THRESH_MOD] ?: 30,
            thresholdHighMinutes = p[Keys.THRESH_HIGH] ?: 60,
            autoDetectDistracting = p[Keys.AUTO_DETECT] ?: true,
            interventionEnabled = p[Keys.INTERVENTION] ?: true,
            theme = runCatching { AppTheme.valueOf(p[Keys.THEME] ?: "SYSTEM") }.getOrDefault(AppTheme.SYSTEM),
            gridColumns = p[Keys.GRID_COLS] ?: 4,
            showLabels = p[Keys.SHOW_LABELS] ?: true,
            demoModeEnabled = p[Keys.DEMO_MODE] ?: false,
            customFrequencyMinutes = p[Keys.CUSTOM_FREQ] ?: 20,
            customMinShift = p[Keys.CUSTOM_MIN_SHIFT] ?: 2,
            customMaxShift = p[Keys.CUSTOM_MAX_SHIFT] ?: 8
        )
    }

    suspend fun setOnboardingComplete(done: Boolean) = edit { it[Keys.ONBOARDING] = done }
    suspend fun setScramblingEnabled(enabled: Boolean) = edit { it[Keys.SCRAMBLING_ENABLED] = enabled }
    suspend fun setIntensity(intensity: ScrambleIntensity) = edit { it[Keys.INTENSITY] = intensity.name }
    suspend fun setThresholds(low: Int, moderate: Int, high: Int) = edit {
        it[Keys.THRESH_LOW] = low; it[Keys.THRESH_MOD] = moderate; it[Keys.THRESH_HIGH] = high
    }
    suspend fun setAutoDetect(enabled: Boolean) = edit { it[Keys.AUTO_DETECT] = enabled }
    suspend fun setIntervention(enabled: Boolean) = edit { it[Keys.INTERVENTION] = enabled }
    suspend fun setTheme(theme: AppTheme) = edit { it[Keys.THEME] = theme.name }
    suspend fun setGridColumns(cols: Int) = edit { it[Keys.GRID_COLS] = cols }
    suspend fun setShowLabels(show: Boolean) = edit { it[Keys.SHOW_LABELS] = show }
    suspend fun setDemoMode(enabled: Boolean) = edit { it[Keys.DEMO_MODE] = enabled }
    suspend fun setCustomRules(freqMinutes: Int, minShift: Int, maxShift: Int) = edit {
        it[Keys.CUSTOM_FREQ] = freqMinutes; it[Keys.CUSTOM_MIN_SHIFT] = minShift; it[Keys.CUSTOM_MAX_SHIFT] = maxShift
    }

    private suspend fun edit(block: (MutablePreferences) -> Unit) {
        context.dataStore.edit { block(it) }
    }
}
