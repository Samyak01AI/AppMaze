package com.appmaze.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.appmaze.app.data.ScrambleIntensity
import com.appmaze.app.launcher.GridApp

private data class OnboardingPage(val title: String, val body: String)

private val staticPages = listOf(
    OnboardingPage("Meet AppMaze", "Your distracting apps aren't blocked.\nThey're just a little harder to find."),
    OnboardingPage("Break the habit loop", "AppMaze disrupts automatic tapping by changing the position of distracting apps.")
)

@Composable
fun OnboardingFlow(
    apps: List<GridApp>,
    hasUsageAccess: Boolean,
    onToggleDistracting: (String, Boolean) -> Unit,
    onIntensitySelected: (ScrambleIntensity) -> Unit,
    onRequestUsageAccess: () -> Unit,
    onRequestDefaultLauncher: () -> Unit,
    onFinished: () -> Unit
) {
    var step by remember { mutableIntStateOf(0) }
    val totalSteps = 6

    Column(Modifier.fillMaxSize().padding(24.dp)) {
        LinearProgressIndicator(
            progress = { (step + 1) / totalSteps.toFloat() },
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(32.dp))

        Box(Modifier.weight(1f)) {
            when (step) {
                0, 1 -> StaticPage(staticPages[step])
                2 -> Column {
                    Text("Choose your distractions", style = MaterialTheme.typography.headlineMedium)
                    Spacer(Modifier.height(12.dp))
                    ChooseDistractionsScreen(apps = apps, onToggle = onToggleDistracting, onDone = { step++ })
                }
                3 -> PermissionPage(
                    title = "Enable Screen Time",
                    body = "AppMaze needs Usage Access to know how long you've spent in each app today. This data never leaves your device.",
                    granted = hasUsageAccess,
                    onRequest = onRequestUsageAccess
                )
                4 -> IntensityPage(onSelected = { onIntensitySelected(it); step++ })
                5 -> LauncherPage(onRequestDefaultLauncher = onRequestDefaultLauncher, onFinish = onFinished)
            }
        }

        if (step !in listOf(2, 4, 5)) {
            Spacer(Modifier.height(16.dp))
            Button(onClick = { step++ }, modifier = Modifier.fillMaxWidth()) {
                Text(if (step == totalSteps - 1) "Get Started" else "Next")
            }
        }
    }
}

@Composable
private fun StaticPage(page: OnboardingPage) {
    Column(
        Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(page.title, style = MaterialTheme.typography.headlineMedium, textAlign = TextAlign.Center)
        Spacer(Modifier.height(16.dp))
        Text(page.body, style = MaterialTheme.typography.bodyLarge, textAlign = TextAlign.Center)
    }
}

@Composable
private fun PermissionPage(title: String, body: String, granted: Boolean, onRequest: () -> Unit) {
    Column(
        Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(title, style = MaterialTheme.typography.headlineMedium, textAlign = TextAlign.Center)
        Spacer(Modifier.height(16.dp))
        Text(body, style = MaterialTheme.typography.bodyLarge, textAlign = TextAlign.Center)
        Spacer(Modifier.height(24.dp))
        if (granted) {
            Text("✓ Usage Access granted", style = MaterialTheme.typography.titleMedium)
        } else {
            Button(onClick = onRequest) { Text("Enable Usage Access") }
        }
    }
}

@Composable
private fun IntensityPage(onSelected: (ScrambleIntensity) -> Unit) {
    Column(
        Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("Choose your intensity", style = MaterialTheme.typography.headlineMedium, textAlign = TextAlign.Center)
        Spacer(Modifier.height(24.dp))
        listOf(ScrambleIntensity.GENTLE, ScrambleIntensity.MODERATE, ScrambleIntensity.STRONG).forEach { intensity ->
            OutlinedButton(
                onClick = { onSelected(intensity) },
                modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp)
            ) {
                Text(intensity.name.lowercase().replaceFirstChar { it.uppercase() })
            }
        }
    }
}

@Composable
private fun LauncherPage(onRequestDefaultLauncher: () -> Unit, onFinish: () -> Unit) {
    Column(
        Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("Set AppMaze as your launcher", style = MaterialTheme.typography.headlineMedium, textAlign = TextAlign.Center)
        Spacer(Modifier.height(16.dp))
        Text(
            "Press Home, then choose AppMaze. This lets AppMaze replace your normal home screen.",
            style = MaterialTheme.typography.bodyLarge,
            textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(24.dp))
        Button(onClick = onRequestDefaultLauncher, modifier = Modifier.fillMaxWidth()) {
            Text("Choose Default Launcher")
        }
        Spacer(Modifier.height(12.dp))
        TextButton(onClick = onFinish) { Text("I'll do this later") }
    }
}
