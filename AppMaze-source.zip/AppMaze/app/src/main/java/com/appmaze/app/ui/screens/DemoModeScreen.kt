package com.appmaze.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.appmaze.app.launcher.GridApp

/**
 * Section 20: DEMO / TEST MODE.
 * Lets a demo/test build simulate usage and manually trigger scrambling
 * without waiting for real UsageStatsManager data to accumulate.
 * Clearly separated from production flows — only reachable when
 * Settings > Developer > "Demo mode" is enabled.
 */
@Composable
fun DemoModeScreen(
    apps: List<GridApp>,
    onSimulateUsage: (packageName: String, addMinutes: Int) -> Unit,
    onScrambleNow: (packageName: String) -> Unit,
    onResetLayout: () -> Unit,
    onBack: () -> Unit
) {
    Column(Modifier.fillMaxSize().padding(20.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) {
                Icon(androidx.compose.material.icons.Icons.Filled.ArrowBack, contentDescription = "Back")
            }
            Text("Demo Mode", style = MaterialTheme.typography.headlineMedium)
        }
        Text(
            "Simulate screen time to preview scrambling instantly.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(Modifier.height(16.dp))

        OutlinedButton(onClick = onResetLayout) { Text("Reset Layout") }
        Spacer(Modifier.height(12.dp))

        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(apps.filterNot { it.isEssential }, key = { it.packageName }) { app ->
                Surface(shape = RoundedCornerShape(16.dp), color = MaterialTheme.colorScheme.surfaceVariant) {
                    Column(Modifier.padding(14.dp)) {
                        Text(app.appName, style = MaterialTheme.typography.titleMedium)
                        Text(
                            "Current usage: ${formatDuration(app.dailyUsageMillis)} · position ${app.position}",
                            style = MaterialTheme.typography.bodyMedium
                        )
                        Spacer(Modifier.height(8.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(onClick = { onSimulateUsage(app.packageName, 30) }) {
                                Text("Simulate +30 min")
                            }
                            Button(onClick = { onScrambleNow(app.packageName) }) {
                                Text("Scramble Now")
                            }
                        }
                    }
                }
            }
        }
    }
}
