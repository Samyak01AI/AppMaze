package com.appmaze.app.apps

import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.graphics.drawable.Drawable
import com.appmaze.app.data.AppDao
import com.appmaze.app.data.AppEntity

data class LaunchableApp(
    val packageName: String,
    val label: String,
    val icon: Drawable?
)

/** Packages we never scramble unless the user explicitly overrides it (Section 8). */
private val ESSENTIAL_PACKAGE_HINTS = listOf(
    "dialer", "phone", "contacts", "settings", "emergency", "sos", "messaging"
)

class InstalledAppsRepository(
    private val context: Context,
    private val appDao: AppDao
) {
    private val pm: PackageManager get() = context.packageManager

    /** Section 3: dynamically discover whatever launchable apps exist on this device. */
    fun queryLaunchableApps(): List<LaunchableApp> {
        val intent = Intent(Intent.ACTION_MAIN).apply { addCategory(Intent.CATEGORY_LAUNCHER) }
        val resolveInfos = pm.queryIntentActivities(intent, PackageManager.MATCH_ALL)
        return resolveInfos
            .filter { it.activityInfo.packageName != context.packageName }
            .distinctBy { it.activityInfo.packageName }
            .map { ri ->
                LaunchableApp(
                    packageName = ri.activityInfo.packageName,
                    label = ri.loadLabel(pm).toString(),
                    icon = runCatching { ri.loadIcon(pm) }.getOrNull()
                )
            }
            .sortedBy { it.label.lowercase() }
    }

    fun isEssential(packageName: String, appInfo: ApplicationInfo?): Boolean {
        val isSystem = appInfo?.let { it.flags and ApplicationInfo.FLAG_SYSTEM != 0 } ?: false
        val nameHints = ESSENTIAL_PACKAGE_HINTS.any { packageName.contains(it, ignoreCase = true) }
        return isSystem || nameHints
    }

    /**
     * First-run + ongoing sync: makes sure every launchable app on the device
     * has a persisted AppEntity row (Section 18), appending new apps at the end
     * of the grid and never touching existing saved positions.
     */
    suspend fun syncInstalledAppsToDb() {
        val installed = queryLaunchableApps()
        val existing = appDao.getAllOnce().associateBy { it.packageName }
        var nextPosition = (appDao.getMaxPosition() ?: -1) + 1

        val toInsert = mutableListOf<AppEntity>()
        for (app in installed) {
            if (existing.containsKey(app.packageName)) continue
            val appInfo = runCatching { pm.getApplicationInfo(app.packageName, 0) }.getOrNull()
            toInsert += AppEntity(
                packageName = app.packageName,
                appName = app.label,
                position = nextPosition++,
                isEssential = isEssential(app.packageName, appInfo)
            )
        }
        if (toInsert.isNotEmpty()) appDao.insertAll(toInsert)

        // Clean up apps the user uninstalled since last sync.
        val installedPackages = installed.map { it.packageName }.toSet()
        for (pkg in existing.keys) {
            if (pkg !in installedPackages) appDao.deleteByPackage(pkg)
        }
    }

    fun launchApp(packageName: String) {
        val launchIntent = pm.getLaunchIntentForPackage(packageName)
        launchIntent?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        launchIntent?.let { context.startActivity(it) }
    }
}
