package com.appmaze.app.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [AppEntity::class, ScrambleEvent::class, InterruptionEvent::class],
    version = 1,
    exportSchema = false
)
abstract class AppMazeDatabase : RoomDatabase() {
    abstract fun appDao(): AppDao
    abstract fun scrambleDao(): ScrambleDao

    companion object {
        @Volatile private var INSTANCE: AppMazeDatabase? = null

        fun getInstance(context: Context): AppMazeDatabase =
            INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    AppMazeDatabase::class.java,
                    "appmaze.db"
                ).fallbackToDestructiveMigration()
                    .build().also { INSTANCE = it }
            }
    }
}
