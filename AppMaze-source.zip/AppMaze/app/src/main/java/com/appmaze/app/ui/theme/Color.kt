package com.appmaze.app.ui.theme

import androidx.compose.ui.graphics.Color

// Calm, premium, low-saturation palette — no aggressive "danger red" (Section 22).
val MazeIndigo = Color(0xFF4A4E9E)
val MazeIndigoLight = Color(0xFF7B7FD0)
val MazeSlate = Color(0xFF2C2E3A)
val MazeMist = Color(0xFFF4F4FA)
val MazeAmber = Color(0xFFE0A458)     // used sparingly for "distraction" indicators, never harsh red
val MazeSage = Color(0xFF7C9885)      // calm positive/neutral accent

val DarkBackground = Color(0xFF15161D)
val DarkSurface = Color(0xFF1E1F29)
val LightBackground = Color(0xFFFAFAFD)
val LightSurface = Color(0xFFFFFFFF)
