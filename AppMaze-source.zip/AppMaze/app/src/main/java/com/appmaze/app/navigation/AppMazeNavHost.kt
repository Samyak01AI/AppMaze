package com.appmaze.app.navigation

import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.platform.LocalContext
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.appmaze.app.launcher.LauncherViewModel
import com.appmaze.app.ui.screens.*

object Routes {
    const val ONBOARDING = "onboarding"
    const val HOME = "home"
    const val DASHBOARD = "dashboard"
    const val SETTINGS = "settings"
    const val CHOOSE_DISTRACTIONS = "choose_distractions"
    const val DEMO_MODE = "demo_mode"
}

@Composable
fun AppMazeNavHost(
    viewModel: LauncherViewModel,
    onRequestUsageAccess: () -> Unit,
    onRequestDefaultLauncher: () -> Unit
) {
    val navController = rememberNavController()
    val uiState by viewModel.uiState.collectAsState()
    val settings by viewModel.settings.collectAsState()

    val startDestination = if (settings.onboardingComplete) Routes.HOME else Routes.ONBOARDING

    NavHost(navController = navController, startDestination = startDestination) {

        composable(Routes.ONBOARDING) {
            OnboardingFlow(
                apps = uiState.apps,
                hasUsageAccess = uiState.hasUsageAccess,
                onToggleDistracting = viewModel::toggleDistracting,
                onIntensitySelected = viewModel::setIntensity,
                onRequestUsageAccess = onRequestUsageAccess,
                onRequestDefaultLauncher = onRequestDefaultLauncher,
                onFinished = {
                    viewModel.setOnboardingComplete(true)
                    navController.navigate(Routes.HOME) { popUpTo(Routes.ONBOARDING) { inclusive = true } }
                }
            )
        }

        composable(Routes.HOME) {
            if (uiState.pendingIntervention != null) {
                InterventionDialog(
                    app = uiState.pendingIntervention!!,
                    onOpenAnyway = viewModel::confirmOpenAnyway,
                    onTakeBreak = viewModel::dismissIntervention
                )
            }
            HomeScreen(
                state = uiState,
                onSearchChange = viewModel::onSearchQueryChange,
                onAppTap = { viewModel.onAppTapped(it) },
                onOpenDashboard = { navController.navigate(Routes.DASHBOARD) },
                onOpenSettings = { navController.navigate(Routes.SETTINGS) },
                gridColumns = settings.gridColumns
            )
        }

        composable(Routes.DASHBOARD) {
            val today = uiState.apps.sortedByDescending { it.dailyUsageMillis }
            DashboardScreen(
                stats = DashboardStats(
                    todayTotalMillis = uiState.todayTotalUsageMillis,
                    topApps = today,
                    distractingApps = uiState.apps.filter { it.isDistracting },
                    scramblesToday = 0,
                    interruptionsToday = 0
                ),
                onBack = { navController.popBackStack() }
            )
        }

        composable(Routes.SETTINGS) {
            SettingsScreen(
                settings = settings,
                hasUsageAccess = uiState.hasUsageAccess,
                onBack = { navController.popBackStack() },
                onScramblingEnabledChange = viewModel::setScramblingEnabled,
                onIntensityChange = viewModel::setIntensity,
                onAutoDetectChange = viewModel::setAutoDetect,
                onInterventionChange = viewModel::setIntervention,
                onThemeChange = viewModel::setTheme,
                onDemoModeChange = viewModel::setDemoMode,
                onRequestUsageAccess = onRequestUsageAccess,
                onResetLayout = viewModel::resetLayout,
                onSetAsDefaultLauncher = onRequestDefaultLauncher,
                onOpenChooseDistractions = { navController.navigate(Routes.CHOOSE_DISTRACTIONS) }
            )
        }

        composable(Routes.CHOOSE_DISTRACTIONS) {
            ChooseDistractionsScreen(
                apps = uiState.apps,
                onToggle = viewModel::toggleDistracting,
                onDone = { navController.popBackStack() }
            )
        }

        composable(Routes.DEMO_MODE) {
            DemoModeScreen(
                apps = uiState.apps,
                onSimulateUsage = viewModel::simulateUsage,
                onScrambleNow = viewModel::scrambleNow,
                onResetLayout = viewModel::resetLayout,
                onBack = { navController.popBackStack() }
            )
        }
    }
}
